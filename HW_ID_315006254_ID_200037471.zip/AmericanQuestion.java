package id315006254_id200037471;

import java.util.Arrays;
import java.util.Random;

public class AmericanQuestion extends Question {

	public enum addAnswerStatus {
		Answer_Already_Exist, No_Place_For_More_Answer, Answer_Added_Succesfully

	}

	private final int MAX_NUM_OF_ANSWERS = 10;
	private int numOfAnswers;
	private AmericanQuestionAnswer[] americanAnswerArray;
	private AmericanQuestionAnswer[] arrayForAutomatic;

	public AmericanQuestion(String questionText) {
		super(questionText);
		americanAnswerArray = new AmericanQuestionAnswer[MAX_NUM_OF_ANSWERS];
		arrayForAutomatic = new AmericanQuestionAnswer[6];
		numOfAnswers = 0;

	}

	public addAnswerStatus addAnswerToArray(AmericanQuestionAnswer americanQuestionAnswer) {

		if (numOfAnswers == MAX_NUM_OF_ANSWERS) {
			return addAnswerStatus.No_Place_For_More_Answer;
		}

		for (int i = 0; i < numOfAnswers; i++) {
			if (americanAnswerArray[i].equals(americanQuestionAnswer)) {

				return addAnswerStatus.Answer_Already_Exist;
			}
		}

		americanAnswerArray[numOfAnswers++] = americanQuestionAnswer;
		return addAnswerStatus.Answer_Added_Succesfully;

	}

	public void makeRandomArrayAnswers() {
		AmericanQuestionAnswer QQ;
		AmericanQuestionAnswer QQ1;
		String allFalse = "all answers are false ";
		String moreThanOneTrue = "more than one correct answer";
		int counter = 0;

		// shuffel array
		Random rd = new Random();
		for (int i = MAX_NUM_OF_ANSWERS - 1; i > 0; i--) {
			if (americanAnswerArray[i] != null) {
				int j = rd.nextInt(i + 1);
				while (americanAnswerArray[j] == null) {
					j = rd.nextInt(i + 1);
				}
				AmericanQuestionAnswer temp = americanAnswerArray[i];
				americanAnswerArray[i] = americanAnswerArray[j];
				americanAnswerArray[j] = temp;
			}
		}
		// getting new answer array for Automatic test
		int i = 0;
		for (int k = 0; k < americanAnswerArray.length; k++) {
			if (americanAnswerArray[k] != null && americanAnswerArray[k].AnswerText != allFalse
					&& americanAnswerArray[k].AnswerText != moreThanOneTrue && i < 4) {
				if (americanAnswerArray[k].isRightOrFalse()) {
					counter++;
				}
				arrayForAutomatic[i] = americanAnswerArray[k];
				i++;
			}

		}

		if (counter > 1) {
			QQ = new AmericanQuestionAnswer(moreThanOneTrue, true);
			QQ1 = new AmericanQuestionAnswer(allFalse, false);
			arrayForAutomatic[4] = QQ;
			arrayForAutomatic[5] = QQ1;
		}
		if (counter == 0) {
			QQ = new AmericanQuestionAnswer(moreThanOneTrue, false);
			QQ1 = new AmericanQuestionAnswer(allFalse, true);
			arrayForAutomatic[4] = QQ;
			arrayForAutomatic[5] = QQ1;
		}
		if (counter == 1) {
			QQ = new AmericanQuestionAnswer(moreThanOneTrue, false);
			QQ1 = new AmericanQuestionAnswer(allFalse, false);
			arrayForAutomatic[4] = QQ;
			arrayForAutomatic[5] = QQ1;
		}
		this.setArrayForAutomatic(arrayForAutomatic);
	}

	// adding for all questions
	public void adding2AnswersToArray() {
		AmericanQuestionAnswer QQ;
		AmericanQuestionAnswer QQ1;
		String allFalse = "all answers are false ";
		String moreThanOneTrue = "more than one correct answer";
		int counter = 0;
		while (americanAnswerArray[numOfAnswers] == null) {

			for (int i = 0; i < numOfAnswers; i++) {
				if (americanAnswerArray[i] != null) {
					if (americanAnswerArray[i].isRightOrFalse()) {
						counter++;
					}

				}
			}
			if (counter > 1) {
				QQ = new AmericanQuestionAnswer(moreThanOneTrue, true);
				QQ1 = new AmericanQuestionAnswer(allFalse, false);
				americanAnswerArray[numOfAnswers] = QQ;
				americanAnswerArray[numOfAnswers + 1] = QQ1;
			}
			if (counter == 0) {
				QQ = new AmericanQuestionAnswer(moreThanOneTrue, false);
				QQ1 = new AmericanQuestionAnswer(allFalse, true);
				americanAnswerArray[numOfAnswers] = QQ;
				americanAnswerArray[numOfAnswers + 1] = QQ1;
			}
			if (counter == 1) {
				QQ = new AmericanQuestionAnswer(moreThanOneTrue, false);
				QQ1 = new AmericanQuestionAnswer(allFalse, false);
				americanAnswerArray[numOfAnswers] = QQ;
				americanAnswerArray[numOfAnswers + 1] = QQ1;
			}
		}

	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object other) {
		if (!(other instanceof AmericanQuestion))
			return false;
		if (!(super.equals(other)))
			return false;

		return true;
	}

	@Override
	public String toString() {
		int k = 1;
		String strAmericanQuestion;
		String testType = Test.getTestType();
		if (testType == "manual") {
			strAmericanQuestion = getClass().getSimpleName() + ": " + questionText + "\n" + "The answers:" + "\n";
			for (int i = 0; i < americanAnswerArray.length; i++) {
				if (americanAnswerArray[i] != null && americanAnswerArray[i].getAnswerText() != null) {
					strAmericanQuestion += (k) + ") " + americanAnswerArray[i].getAnswerText() + "\n";
				} else {
					k--;
				}
				k++;
			}
			return strAmericanQuestion;

		}
		if (testType == "automatic") {
			strAmericanQuestion = getClass().getSimpleName() + ": " + questionText + "\n" + "The answers:" + "\n";
			for (int i = 0; i < arrayForAutomatic.length; i++) {
				if (arrayForAutomatic[i] != null && arrayForAutomatic[i].getAnswerText() != null) {
					strAmericanQuestion += (k) + ") " + arrayForAutomatic[i].getAnswerText() + "\n";
				} else {
					k--;
				}
				k++;
			}
			return strAmericanQuestion;

		}
		return null;
	}

	public String toStringForDataBase() {
		int k = 1;
		String strAmericanQuestion;

		strAmericanQuestion = getClass().getSimpleName() + ": " + questionText + "\n" + "The answers:" + "\n";
		for (int i = 0; i < americanAnswerArray.length; i++) {
			if (americanAnswerArray[i] != null && americanAnswerArray[i].getAnswerText() != null) {
				strAmericanQuestion += (k) + ") " + americanAnswerArray[i].getAnswerText()
						+ americanAnswerArray[i].toString();
			} else {
				k--;
			}
			k++;
		}
		return strAmericanQuestion;

	}

	public int getNumOfAnswers() {
		return numOfAnswers;
	}

	public void setNumOfAnswers(int numOfAnswers) {
		this.numOfAnswers = numOfAnswers;
	}

	public AmericanQuestionAnswer[] getAnswersArray() {
		return americanAnswerArray;
	}

	public void setAnswersArray(AmericanQuestionAnswer[] answersArray) {
		this.americanAnswerArray = answersArray;
	}

	public void setArrayForAutomatic(AmericanQuestionAnswer[] arrayForAutomatic) {
		this.arrayForAutomatic = arrayForAutomatic;
	}

	public int getMAX_NUM_OF_ANSWERS() {
		return MAX_NUM_OF_ANSWERS;
	}

	public boolean setAmericanQuestionAnswer(String text, int indexAnswer, boolean TOF) {

		if (!(indexAnswer < 0 || indexAnswer > 10 || americanAnswerArray[indexAnswer] == null)) {

			americanAnswerArray[indexAnswer].setAnswerText(text);
			americanAnswerArray[indexAnswer].setRightOrFalse(TOF);

			return true;
		}
		return false;
	}

}