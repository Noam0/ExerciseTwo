package id315006254_id200037471;

import java.util.Arrays;
import java.util.Random;


public class DataBase {

  public enum addQuestionStatus {
	Question_Added_Succesfully, Question_Already_Exist ,Question_Changed_Succesfully , Didnt_Find_The_Question , Answer_Changed_Succesfully,Index_Out_Of_Bounds
	}

	private static Question[] allQuestionsArray;
	private Test[] allTestsArray;
	private int numOfAllQuestions;
	private int numOfAllTests;

	public DataBase() {
		allTestsArray = new Test[10];
		allQuestionsArray = new Question[1];
		numOfAllQuestions = 0;
		numOfAllTests = 0;

	}

	public addQuestionStatus addQuestionToDataBase(Question question) {
			if (findQuestion(question)) {
				return addQuestionStatus.Question_Already_Exist;
			} else if (allQuestionsArray.length == numOfAllQuestions) {
				allQuestionsArray = Arrays.copyOf(allQuestionsArray, allQuestionsArray.length * 2);
				allQuestionsArray[numOfAllQuestions++] = question;
				return addQuestionStatus.Question_Added_Succesfully;
			} else {
				allQuestionsArray[numOfAllQuestions++] = question;
				return addQuestionStatus.Question_Added_Succesfully;
			}
		}
	


	
	
	public boolean findQuestion(Question question) {
		
		for (int i = 0; i < numOfAllQuestions ; i++) {
			if (allQuestionsArray[i] instanceof OpenQuestion) {
				OpenQuestion openQuestionTemp = (OpenQuestion)allQuestionsArray[i];
				if (openQuestionTemp.equals(question)) 
					return true;
		      }		
			if (allQuestionsArray[i] instanceof AmericanQuestion) {
				 AmericanQuestion americanQuestionTemp = (AmericanQuestion)allQuestionsArray[i];
				if (americanQuestionTemp.equals(question))
					return true;
		      }
	        }
	        return false;
	     }

	public addQuestionStatus editQuestionText(int questionId, String text) {

		for (int i = 0; i < numOfAllQuestions ; i++) {
			if (questionId == allQuestionsArray[i].getQuestionId()) {
				allQuestionsArray[i].setQuestionText(text);
			 return addQuestionStatus.Question_Changed_Succesfully;
			}
		}
		return addQuestionStatus.Didnt_Find_The_Question;
		
		
	}

	public addQuestionStatus editOpenQustionAnswerText(int questionId, String text) {
		
		if (numOfAllQuestions + 1000 < questionId || questionId< 1000  ) {
			return addQuestionStatus.Didnt_Find_The_Question;
		}else {
		for (int i = 0; i < numOfAllQuestions ; i++) {
			if (allQuestionsArray[i] instanceof OpenQuestion && questionId == allQuestionsArray[i].getQuestionId()) {
				OpenQuestion openQuestion = (OpenQuestion)allQuestionsArray[i];
				openQuestion.setQuestionAnswer(text);
				return addQuestionStatus.Answer_Changed_Succesfully;

			}
		}
		return addQuestionStatus.Didnt_Find_The_Question;
		}
	}

	public addQuestionStatus editAmericanQuestionAnswerText(int questionId, String text, int indexAnswer, boolean TOF) {

		if (numOfAllQuestions + 1000 < questionId || questionId< 1000  ) {
			return addQuestionStatus.Didnt_Find_The_Question;
		}else {
		boolean flag = true;
		int i = 0;
		for ( i = 0; i < numOfAllQuestions && flag ; i++) {
			if (allQuestionsArray[i] instanceof AmericanQuestion && questionId == allQuestionsArray[i].getQuestionId())  
			    flag = false;
			
			}
			AmericanQuestion americanQuestion = (AmericanQuestion)allQuestionsArray[(i-1)];
		
				if(americanQuestion.setAmericanQuestionAnswer(text, indexAnswer, TOF))
				return addQuestionStatus.Answer_Changed_Succesfully;
				
			    return 	addQuestionStatus.Index_Out_Of_Bounds;
			
		}
	}
	
	public static Question findingQuestionFromId(int questionId) {

		for (int i = 0; i < allQuestionsArray.length; i++) {
			if(allQuestionsArray[i]==null) {
				System.out.println("Error no match!");
			  return null;
			}
			if (questionId == allQuestionsArray[i].getQuestionId()) {
				return allQuestionsArray[i];
			}
		}
		System.out.println("Error no match!");
		  return null;
	}
	
	public Test[] getAllTestsArray() {
		return allTestsArray;
	}

	public int getNumOfAllTests() {
		return numOfAllTests;
	}
	public int getNumOfAllQuestions() {
		return numOfAllQuestions;
	}

	@Override
	public String toString() {
		String strDataBase;
		strDataBase = "~~~~~~~~~~~~DataBase questions:~~~~~~~~~~~~" + "\n" + "\n";

		for (int i = 0; i < allQuestionsArray.length; i++) {
			if (allQuestionsArray[i] != null) {
				if (allQuestionsArray[i] instanceof OpenQuestion) {
					OpenQuestion openQuestion = (OpenQuestion) allQuestionsArray[i];

					strDataBase += openQuestion.questionId + ")" + openQuestion.toString() + "\n" + "Answer: "
							+ openQuestion.getQuestionAnswer() + "\n" + "\n";
				}
		if (allQuestionsArray[i] instanceof AmericanQuestion) {
		  AmericanQuestion americanQuestion = (AmericanQuestion) allQuestionsArray[i];
		  americanQuestion.adding2AnswersToArray();

					strDataBase += americanQuestion.questionId +")" + americanQuestion.toStringForDataBase() + "\n";
							
				}
			}
		}
		return strDataBase;
	}
		                                                          
	public Test creatingTest(int numberOfQuestionInTest) {

		Test test = new Test(numberOfQuestionInTest , "manual");
		allTestsArray[numOfAllTests++] = test;
		return test;

	}

	public Test makeAutomaticTest(int numberOfQuestionInTest, String testType) {
		Test test = new Test(numberOfQuestionInTest , "automatic");
		Random r = new Random();
		int randomId;

		for (int i = 0; i < numberOfQuestionInTest ; i++) {
			randomId = 1000 + r.nextInt(numOfAllQuestions);
		if(test.addQuestionToTest(randomId)) {
			i--;
		 }
		else {
			Question question = DataBase.findingQuestionFromId(randomId);
			if(question instanceof AmericanQuestion) {
			AmericanQuestion americanQuestionTemp = (AmericanQuestion)question;
			americanQuestionTemp.makeRandomArrayAnswers();
					
				
			}
		}
    }
		test.sortArrayTestQuestion();
		allTestsArray[numOfAllTests++] = test;
		return test;

	}
	public void addingQuestionAutomatically() {

		//first Open questions:
		Question Q1 = new OpenQuestion("What is the exact radius of the earth?", "6,371 km");
		Question Q2 = new OpenQuestion("How many times Argentina won the  World Cup Tournament?", "2");
		Question Q3 = new OpenQuestion("What was Freddie Mercury�s real name?", "Farrokh Bulsara");
		Question Q4 = new OpenQuestion("Believe it or not, Jimi Hendrix only had one Top 40 hit Which song was it?","All Along The WatchOver");
		Question Q5 = new OpenQuestion("What's the capital of Brazil?" , "Brasilia" );	
		
		
		AmericanQuestion Q6 = new AmericanQuestion("Solve this equation - e^pi*i - 1 = ? ");
		//this american question answers:
		AmericanQuestionAnswer A1 = new AmericanQuestionAnswer("1", false);
		AmericanQuestionAnswer A2 = new AmericanQuestionAnswer("0", true);
		AmericanQuestionAnswer A3 = new AmericanQuestionAnswer("2", true);
		AmericanQuestionAnswer A6 = new AmericanQuestionAnswer("4", true);
		AmericanQuestionAnswer A4 = new AmericanQuestionAnswer("55", false);
		AmericanQuestionAnswer A5 = new AmericanQuestionAnswer("6", false);
		
		//adding answer to the question
		Q6.addAnswerToArray(A1);
		Q6.addAnswerToArray(A2);
		Q6.addAnswerToArray(A3);
		Q6.addAnswerToArray(A4);
		Q6.addAnswerToArray(A5);
		Q6.addAnswerToArray(A6);
		
		
		AmericanQuestion Q7 = new AmericanQuestion("what five colours are the Olympic rings?");
		//this american question answers:
		AmericanQuestionAnswer AB1 = new AmericanQuestionAnswer("Red, Pink, White, blue and yellow", false);
		AmericanQuestionAnswer AB2 = new AmericanQuestionAnswer("black, blue, red, green, grey", false);
		AmericanQuestionAnswer AB3 = new AmericanQuestionAnswer("blue, black, red, yellow, green", true);
		AmericanQuestionAnswer AB4 = new AmericanQuestionAnswer("yellow, pink, black, red, blue ", false);
		AmericanQuestionAnswer AB5 = new AmericanQuestionAnswer("black, grey, white, blue, yellow", false);
		AmericanQuestionAnswer AB6 = new AmericanQuestionAnswer("all rings are black and white", false);
		
	//adding answer to the question
		Q7.addAnswerToArray(AB1);
		Q7.addAnswerToArray(AB2);
		Q7.addAnswerToArray(AB3);
		Q7.addAnswerToArray(AB4);
		Q7.addAnswerToArray(AB5);
		Q7.addAnswerToArray(AB6);
		
	
	//adding all questions to data base
		addQuestionToDataBase(Q1);
		addQuestionToDataBase(Q2);
		addQuestionToDataBase(Q3);
		addQuestionToDataBase(Q4);
		addQuestionToDataBase(Q5);
		addQuestionToDataBase(Q6);
		addQuestionToDataBase(Q7);

	}

}