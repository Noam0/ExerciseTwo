package id315006254_id200037471;


public abstract class Question {

	
	public int questionId;
	public static int idGenerator = 1000;
	public String questionText;
	
	public Question(String questionText) {
		super();
		this.questionText = questionText;
		questionId = idGenerator++;
	}

	public int getQuestionId() {
		return questionId;
	}

	
	public void setQuestionText(String questionText) {
		this.questionText = questionText;
	}
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((questionText == null) ? 0 : questionText.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object other) {
		if (!(other instanceof Question))
			return false;
		
		Question Qtemp = (Question)other;
		return (questionText.equals(Qtemp.questionText)&& Qtemp.hashCode()==this.hashCode()) ;
	}	

	public abstract String toString();
	
}