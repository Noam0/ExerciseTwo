package id315006254_id200037471;

import java.util.Random;

public class Test {

	private static String testType;  //automatic or manually
	private int testId;
	public static int testIdGenerator = 1;
	private int[] testQuestions;
	private int numberOfQuestions;
	private int numberOfQuestionsCounter;

	public Test(int numberOfQuestions , String testType) {
		testId = testIdGenerator++;
		testQuestions = new int[numberOfQuestions];
		this.numberOfQuestions = numberOfQuestions;
		this.testType = testType;
		numberOfQuestionsCounter = 0;
	}

	public boolean addQuestionToTest(int questionId) {
		
		for (int i = 0; i < numberOfQuestionsCounter ; i++) {
			if (questionId == testQuestions[i]) {
				return true;
			}
		}
			if ( DataBase.findingQuestionFromId(questionId) == null ) {
				return true;
			}
		if (numberOfQuestions >= numberOfQuestionsCounter) {
		      testQuestions[numberOfQuestionsCounter++] = questionId;
		        return false;
		}
		return false;
	}
	

	public static String getTestType() {
		return testType;
	}

	@Override
	public String toString() {
		String strTest;
		strTest = " Test number : {" + testId  + "}    ~~~~~" + testType + "~~~~~" + "\n" + "questions : " + "\n";
		for (int i = 0; i < testQuestions.length ; i++) {
			Question question = DataBase.findingQuestionFromId(testQuestions[i]);
			if(question!=null) {
				if (question instanceof OpenQuestion) {
				OpenQuestion openQuestion = (OpenQuestion)question;
				
				strTest += openQuestion.questionId  + "}" + openQuestion.toString() + "\n" + "\n";
			    }
				if (question instanceof AmericanQuestion) {
				AmericanQuestion americanQuestion = (AmericanQuestion)question;
	
				strTest += americanQuestion.questionId  + "}" + americanQuestion.toString() + "\n" ;
			   }
		      }
		    }
		     return strTest;
	    }

	public void sortArrayTestQuestion () {
		int temp = 0;
		char firstCharText;
		char firstCharText1;
		int k;
		for (int i = testQuestions.length-1 ; i >= 0 ; i--) {
		  for (int j = 1 ; j <= i ; j++) {
			Question questionTemp = DataBase.findingQuestionFromId(testQuestions[j-1]);
			Question questionTemp1 = DataBase.findingQuestionFromId(testQuestions[j]);
			if(questionTemp!=null && questionTemp1!=null ) {
			String textTemp = questionTemp.questionText;
			String textTemp1 = questionTemp1.questionText;
		    firstCharText = textTemp.charAt(0);
		    firstCharText1 = textTemp1.charAt(0);
		    firstCharText = Character.toLowerCase( firstCharText);
		    firstCharText1 = Character.toLowerCase( firstCharText1);
			k = 0;
			if(firstCharText>firstCharText1 || Character.isDigit( firstCharText)) {
				temp = testQuestions[j-1];
				testQuestions[j-1] = testQuestions[j];
				testQuestions[j] = temp;
			}
			while(firstCharText==firstCharText1 && firstCharText != '?' && firstCharText1!= '?' ) {
		        firstCharText = textTemp.charAt(k);
				firstCharText1 = textTemp1.charAt(k);
				firstCharText = Character.toLowerCase( firstCharText);
				firstCharText1 = Character.toLowerCase( firstCharText1);
				k++;
			}
			if(firstCharText>firstCharText1 && k>0) {
				temp = testQuestions[j-1];
				testQuestions[j-1] = testQuestions[j];
				testQuestions[j] = temp;
			   }
			
			}	
		}
		  
	}
  }
}